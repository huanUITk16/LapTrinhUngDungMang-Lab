package bai1;

import log.logFile;

public class bai1 {
	public static void main (String [] args) {
		logFile logger = new logFile("21522108_NguyenVanHuan.txt");
		for (int i=10;i<=200;i++) {
			if (i%7 == 0 && i%5 != 0)
				logger.log(i + ", ");
		}
	}
}
