package bai6;

import java.util.Scanner;

import log.logFile;


public class bai6 {
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
    	logFile logger = new logFile("21522108_NguyenVanHuan.txt");
        logger.log("Nhập số nguyên dương a = ");
        int a = scanner.nextInt();
        logger.log("Nhập số nguyên dương b = ");
        int b = scanner.nextInt();
        
        logger.log("USCLN của " + a + " và " + b
                + " là: " + USCLN(a, b));
        
        logger.log("BSCNN của " + a + " và " + b
                + " là: " + BSCNN(a, b));
    }
     
    
    public static int USCLN(int a, int b) {
        if (b == 0) return a;
        return USCLN(b, a % b);
    }
     

    public static int BSCNN(int a, int b) {
        return (a * b) / USCLN(a, b);
    }
}
