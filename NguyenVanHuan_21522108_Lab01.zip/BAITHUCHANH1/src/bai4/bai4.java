package bai4;

import java.util.Scanner;

import log.logFile;

public class bai4 {
	public static int nhap(){
		logFile logger = new logFile("21522108_NguyenVanHuan.txt");
        Scanner input= new Scanner(System.in);
        boolean check= false;
        int n=0;
        while(!check){
            logger.log(" ");
            try{
                n= input.nextInt();
                check= true;
            }catch(Exception e){
                logger.log("Ban phai nhap so! hay nhap lai...");
                input.nextLine();
            }
        }
        return (n);
	}
	public static void DoiHeCoSo (int n,int base){
        if(n>=base) DoiHeCoSo(n / base, base);
        if(n % base>9) System.out.printf("%c",n%base+55);
        else
        System.out.print((n % base));
    }
	public static void main (String [] args) {
		logFile logger = new logFile("21522108_NguyenVanHuan.txt");
		logger.log("Nhap n:");
		int n = nhap();
		logger.log("Nhap vao co so");
		int b = nhap();
		logger.log("So "+n + " sau khi chuyen sang co so " +b +" la: ");
		DoiHeCoSo(n,b);
	}
}
