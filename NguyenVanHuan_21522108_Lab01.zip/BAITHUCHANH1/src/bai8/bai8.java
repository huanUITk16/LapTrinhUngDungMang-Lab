package bai8;

import log.logFile;

public class bai8 {
	public static boolean isPrimeNumber(int n) {
	        
	        if (n < 2) {
	            return false;
	        }
	        int squareRoot = (int) Math.sqrt(n);
	        for (int i = 2; i <= squareRoot; i++) {
	            if (n % i == 0) {
	                return false;
	            }
	        }
	        return true;
	    }
	public static void main (String []args) {
		logFile logger = new logFile("21522108_NguyenVanHuan.txt");
		logger.log("Cac so nguyen to co 5 chu so: ");
		for (int i = 10000; i< 100000; i++) {
			if (isPrimeNumber(i)==true)
				logger.log(i+ ", ");
		}
	}
	
	
	
}
