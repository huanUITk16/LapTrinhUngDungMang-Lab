package bai2;
import java.util.Scanner;

import log.logFile;
public class bai2 {
		public static void main (String [] args) {
			logFile logger = new logFile("21522108_NguyenVanHuan.txt");
			Scanner input = new Scanner (System.in);
			int fact =1;
			logger.log("Nhap 1 so: ");
			int number = input.nextInt();
			for (int i=1; i<=number;i++) {
				fact = fact*i;
				
			}
			logger.log("Giai thua cua " + number +" la " + fact);
			
				
		
		}
}
