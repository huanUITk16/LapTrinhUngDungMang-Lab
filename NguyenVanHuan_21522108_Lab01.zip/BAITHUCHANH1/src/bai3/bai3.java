package bai3;

import java.util.Scanner;

import log.logFile;

public class bai3 {
	public static void main (String [] args) {
		logFile logger = new logFile("21522108_NguyenVanHuan.txt");
		Scanner input = new Scanner (System.in);
		logger.log("Nhap 1 so: ");
		int number = input.nextInt();
		for (int i=1; i <= number; i++) {
			 if (i==1)
				logger.log("{"); 
			 logger.log(i +": "+ i*i+", ");
			 if (i==number)
				logger.log("}"); 
		}
	}
}
