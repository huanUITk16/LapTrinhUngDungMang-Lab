package bai12;

import java.util.Scanner;

import log.logFile;

public class bai12 {
    public static void main(String[] args) {
    	logFile logger = new logFile("21522108_NguyenVanHuan.txt");
    	Scanner input= new Scanner(System.in);
    	logger.log("Nhap xau 1: ");
        String str1 = input.nextLine();
        logger.log("Nhap xau 2: ");
        String str2 = input.nextLine();
        logger.log(str1.contains(str2));
    }
}
