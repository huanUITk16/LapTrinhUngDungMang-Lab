package bai13;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import log.logFile;

public class bai13 {
	
	public static int nhap(){
        Scanner input= new Scanner(System.in);
        boolean check= false;
        int n=0;
        while(!check){
            System.out.print(" ");
            try{
                n= input.nextInt();
                check= true;
            }catch(Exception e){
                System.out.println("Ban phai nhap so! hay nhap lai...");
                input.nextLine();
            }
        }
        return (n);
    }
	public static void sortASC(Integer[] array) {
        int temp = array[0];
        for (int i = 0 ; i < array.length - 1; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if (array[i] > array[j]) {
                    temp = array[j];
                    array[j] = array[i];
                    array[i] = temp;
                }
            }
        }
    }
	
	public static void show(Integer[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }
	
	public static Integer[] addValue(Integer [] arr, int value ) {
		ArrayList <Integer> arrList = new ArrayList<Integer> (Arrays.asList(arr)); // turn array to list using asList()
		arrList.add(value); // add value to list
		arr = arrList.toArray(arr);
		return arr;
		
	}
	
	public static int getSecondLargest(Integer []a) {
		int temp;
		for (int i=0;i<a.length;i++) {
			for (int j=0;j<a.length;j++) {
				if(a[i]<a[j]) {
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		return a[a.length-2];
		
	}
	public static void main (String[]args) {
		int n,i, value, indexSecondMax = 0;
		int indexMax = 0;
		logFile logger = new logFile("21522108_NguyenVanHuan.txt");
        logger.log("Nhap n= ");
        n= nhap();
        Integer[] array= new Integer[n];
        
        for(i=0 ; i<n ; i++){
            logger.log("Nhap phan tu thu " +(i+1)+" ");
            array[i]= nhap();
        }
        int max = array[0];
        int secondLargestValue = getSecondLargest(array);
        for(i=1 ; i<array.length ; i++){
            if (array[i] > max) {
            	max = array[i];
            	indexMax = i;}
            }
        
        logger.log("Phan tu lon nhat la: "+ max +" index " + indexMax);
        logger.log("Phan tu lon thu hai la: "+ secondLargestValue);
        sortASC(array);
        logger.log("Mang sap xep theo thu tu tang dan: ");
        show(array);
        logger.log("Nhap gia tri muon them vao mang: ");
        value = nhap();
        array = addValue(array, value);
        logger.log("Mang sau khi them gia tri vao: ");
        sortASC(array);
        show(array);
    }
}
