package bai15;

import java.util.Scanner;

import log.logFile;
public class bai15
{
   public static void main(String[] args)
   {
	  logFile logger = new logFile("21522108_NguyenVanHuan.txt");
      String[] code = new String[5];
      Scanner sc = new Scanner(System.in);

      for (int i = 0; i < 5; i++)
      {
         logger.log("Nhập vào mã thứ " + (i+1));
         code[i] = sc.nextLine();
         if(!code[i].matches("00[2-5]L\\d{4}"))
         {
            logger.log("Sai rồi!");
            return;
         }
      }
      logger.log("Đúng rồi!");
   }
}
