package bai7;

import java.util.Scanner;

import log.logFile;

public class bai7 {
    private static Scanner scanner = new Scanner(System.in);
     
    public static void main(String[] args) {
    	logFile logger = new logFile("21522108_NguyenVanHuan.txt");
        logger.log ("Nhập n = ");
        int n = scanner.nextInt();
        logger.log ("Tất cả các số nguyên tố nhỏ hơn "+ n + " là: " + n);
        if (n >= 2) {
            logger.log(2);
        }
        for (int i = 3; i < n; i+=2) {
            if (isPrimeNumber(i)) {
                logger.log(" " + i);
            }
        }
    }
     
    
    public static boolean isPrimeNumber(int n) {
        
        if (n < 2) {
            return false;
        }
        int squareRoot = (int) Math.sqrt(n);
        for (int i = 2; i <= squareRoot; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
