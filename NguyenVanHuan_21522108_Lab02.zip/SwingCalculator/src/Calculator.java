import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import log.logFile;
public class Calculator extends JFrame implements ActionListener {
    logFile logger = new logFile("21522108_NguyenVanHuan_SwingCalculator.txt");
    private DecimalFormat df = new DecimalFormat(("#, ###.0"));
    private String[] symbols = {
            "AC", "+/-", "%", "÷",
            "7", "8", "9", "x",
            "4", "5", "6", "-",
            "1", "2", "3", "+",
            "0", ".", "Adv", "="
    };

    private int operator = 0;
    private JPanel panel = new JPanel(new BorderLayout(5,5));
    private JPanel btnPanel = new JPanel(new GridLayout(5,3,2,2));
    private JButton[] btns = new JButton[20];
    private JTextArea screen = new JTextArea(5,40);
    private double firstNum = 0, secondNum = 0;
    private JTextField calculatingTf = new JTextField(40);

    public Calculator(){
        init();
    }
    private void init(){
        screen.setFont(new Font("Times New Roman", Font.BOLD,18));
        setTitle("Calculator");
        screen.setBackground(Color.BLACK);
        screen.setForeground(Color.WHITE);
        panel.setBackground(Color.BLACK);
        btnPanel.setBackground(Color.BLACK);
        for (int i=0;i<btns.length;i++){
            btns[i] = new JButton(symbols[i]);
            btns[i].setOpaque(false);
            btns[i].setBorderPainted(false);
            btns[i].setBackground(Color.BLACK);
            btns[i].setForeground(Color.WHITE);
            btns[i].addActionListener(this);
            btnPanel.add(btns[i]);
        }
        calculatingTf.setForeground(Color.WHITE);
        calculatingTf.setBackground(Color.BLACK);
        panel.add(calculatingTf, BorderLayout.SOUTH);
        panel.add(btnPanel, BorderLayout.CENTER);
        panel.add(screen, BorderLayout.NORTH);
        add(panel);
        setSize(340,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main (String[] args){
        new Calculator();
    }
    @Override
    public void actionPerformed(ActionEvent e){
        String cmd = e.getActionCommand().toString();
        switch (cmd) {
            case ".":
                logger.log(".");
                if (!screen.getText().contains(".")) {
                    screen.setText(screen.getText() + ".");
                }
                break;
            case "0":
                logger.log("0");
                screen.setText(screen.getText() + "0");
                break;
            case "1":
                logger.log("1");
                screen.setText(screen.getText() + "1");
                break;
            case "2":
                logger.log("2");
                screen.setText(screen.getText() + "2");
                break;
            case "3":
                logger.log("3");
                screen.setText(screen.getText() + "3");
                break;
            case "4":
                logger.log("4");
                screen.setText(screen.getText() + "4");
                break;
            case "5":
                logger.log("5");
                screen.setText(screen.getText() + "5");
                break;
            case "6":
                logger.log("6");
                screen.setText(screen.getText() + "6");
                break;
            case "7":
                logger.log("7");
                screen.setText(screen.getText() + "7");
                break;
            case "8":
                logger.log("8");
                screen.setText(screen.getText() + "8");
                break;
            case "9":
                logger.log("9");
                screen.setText(screen.getText() + "9");
                break;
            case "+":
                logger.log("+");
                if (!screen.getText().isEmpty()) {
                    firstNum = Double.parseDouble(screen.getText().toString());
                    operator = 1;
                    screen.setText("");
                }
                break;
            case "-":
                logger.log("-");
                if (!screen.getText().isEmpty()) {
                    firstNum = Double.parseDouble(screen.getText().toString());
                    operator = 2;
                    screen.setText("");
                }
            case "x":
                logger.log("x");
                if (!screen.getText().isEmpty()) {
                    firstNum = Double.parseDouble(screen.getText().toString());
                    operator = 3;
                    screen.setText("");
                }
                break;
            case "÷":
                logger.log("÷");
                if (!screen.getText().isEmpty()) {
                    firstNum = Double.parseDouble(screen.getText().toString());
                    operator = 4;
                    screen.setText("");
                }
                break;
            case "%":
                logger.log("%");
                double num = Double.parseDouble(screen.getText().toString());
                screen.setText(String.valueOf(num / 100.0));
                logger.log(String.valueOf(num/100.0));
                break;
            case "+/-":
                logger.log("-");
                double neg = Double.parseDouble(screen.getText().toString());
                neg *= -1;
                screen.setText(String.valueOf(neg));
                break;
            case "AC":
                screen.setText("");
                break;

            default:
        }
        if (cmd.equalsIgnoreCase("=")){
            if (!screen.getText().isEmpty()){
                secondNum = Double.parseDouble(screen.getText().toString());
                switch (operator){
                    case 1: // +
                        screen.setText(String.valueOf(firstNum + secondNum));
                        calculatingTf.setText(String.valueOf(firstNum + "+" + secondNum + " = "
                                + (df.format(firstNum + secondNum))));
                        logger.log(df.format(firstNum + secondNum));
                        break;
                    case 2: // -
                        screen.setText(String.valueOf(firstNum - secondNum));
                        calculatingTf.setText(String.valueOf(firstNum + "-" + secondNum + " = "
                                + (df.format(firstNum - secondNum))));
                        logger.log(df.format(firstNum - secondNum));
                        break;
                    case 3: // X
                        screen.setText(String.valueOf(firstNum * secondNum));
                        calculatingTf.setText(String.valueOf(firstNum + "X" + secondNum + " = "
                                + (df.format(firstNum * secondNum))));
                        logger.log(df.format(firstNum * secondNum));
                        break;
                    case 4: // ÷
                        screen.setText(String.valueOf(firstNum / secondNum));
                        calculatingTf.setText(String.valueOf(firstNum + "/" + secondNum + " = "
                                + (df.format(firstNum / secondNum))));
                        logger.log(df.format(firstNum/secondNum));
                        break;
                }
            }
        }
    }
}

