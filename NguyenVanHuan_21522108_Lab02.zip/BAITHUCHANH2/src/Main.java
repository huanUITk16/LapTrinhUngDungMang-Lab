import log.logFile;

import java.awt.*;
import java.awt.event.*;
class MyCalc extends WindowAdapter implements ActionListener{
    logFile logger = new logFile("21522108_NguyenVanHuan_CalculatorAWT.txt");
    Frame f;
    Label l1;
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b0;
    Button  bDEL, bAC, bCalc, bMod, bMulti, bPlus, bMinus, bDivide, bDot,
            bNegative;
    double xd;
    double num1,num2,check;

    MyCalc(){
        f= new Frame("MY CALCULATOR");
        f.setBackground(Color.decode("#ADD8E6"));

        l1=new Label();
        l1.setBackground(Color.WHITE);
        l1.setBounds(50,50,260,60);
        l1.setAlignment(Label.RIGHT);


        b1=new Button("1");
        b1.setBounds(50,340,50,50);
        b2=new Button("2");
        b2.setBounds(120,340,50,50);
        b3=new Button("3");
        b3.setBounds(190,340,50,50);
        b4=new Button("4");
        b4.setBounds(50,270,50,50);
        b5=new Button("5");
        b5.setBounds(120,270,50,50);
        b6=new Button("6");
        b6.setBounds(190,270,50,50);
        b7=new Button("7");
        b7.setBounds(50,200,50,50);
        b8=new Button("8");
        b8.setBounds(120,200,50,50);
        b9=new Button("9");
        b9.setBounds(190,200,50,50);
        b0=new Button("0");
        b0.setBounds(50,410,50,50);
        bNegative=new Button("+/-");
        bNegative.setBounds(120,410,50,50);
        bDot=new Button(".");
        bDot.setBounds(190,410,50,50);
        bDEL=new Button("DEL");
        bDEL.setBounds(50,130,50,50);
        bAC=new Button("AC");
        bAC.setBounds(120,130,50,50);
        bPlus=new Button("+");
        bPlus.setBounds(260,340,50,50);
        bMinus=new Button("-");
        bMinus.setBounds(260,270,50,50);
        bMulti=new Button("X");
        bMulti.setBounds(260,200,50,50);
        bDivide=new Button("/");
        bDivide.setBounds(260,130,50,50);
        bMod=new Button("%");
        bMod.setBounds(190,130,50,50);
        bCalc=new Button("=");
        bCalc.setBounds(260,410,50,50);



        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
        b8.addActionListener(this);
        b9.addActionListener(this);
        b0.addActionListener(this);
        bDot.addActionListener(this);
        bPlus.addActionListener(this);
        bMinus.addActionListener(this);
        bMulti.addActionListener(this);
        bDivide.addActionListener(this);
        bMod.addActionListener(this);
        bCalc.addActionListener(this);
        bDEL.addActionListener(this);
        bAC.addActionListener(this);
        bNegative.addActionListener(this);

        f.addWindowListener(this);
//ADDING TO FRAME   
        f.add(l1);
        f.add(b1); f.add(b2); f.add(b3); f.add(b4); f.add(b5);f.add(b6); f.add(b7); f.add(b8);f.add(b9);f.add(b0);

        f.add(bPlus); f.add(bMinus); f.add(bMod); f.add(bMulti); f.add(bDivide); f.add(bMod);f.add(bCalc);

         f.add(bDot); f.add(bDEL); f.add(bAC); f.add(bNegative);

        f.setSize(360,500);
        f.setLayout(null);
        f.setVisible(true);
    }
    //FOR CLOSING THE WINDOW
    public void windowClosing(WindowEvent e) {
        f.dispose();
    }

    public void actionPerformed(ActionEvent e){
        String z,zt;
        //NUMBER BUTTON
        if(e.getSource()==b1){
            zt=l1.getText();
            z=zt+"1";
            l1.setText(z);
            logger.log("1");
        }
        if(e.getSource()==b2){
            zt=l1.getText();
            z=zt+"2";
            l1.setText(z);
            logger.log("2");
        }
        if(e.getSource()==b3){
            zt=l1.getText();
            z=zt+"3";
            l1.setText(z);
            logger.log("3");
        }
        if(e.getSource()==b4){
            zt=l1.getText();
            z=zt+"4";
            l1.setText(z);
            logger.log("4");
        }
        if(e.getSource()==b5){
            zt=l1.getText();
            z=zt+"5";
            l1.setText(z);
            logger.log("5");
        }
        if(e.getSource()==b6){
            zt=l1.getText();
            z=zt+"6";
            l1.setText(z);
            logger.log("6");
        }
        if(e.getSource()==b7){
            zt=l1.getText();
            z=zt+"7";
            l1.setText(z);
            logger.log("7");
        }
        if(e.getSource()==b8){
            zt=l1.getText();
            z=zt+"8";
            l1.setText(z);
            logger.log("8");
        }
        if(e.getSource()==b9){
            zt=l1.getText();
            z=zt+"9";
            l1.setText(z);
            logger.log("9");
        }
        if(e.getSource()==b0){
            zt=l1.getText();
            z=zt+"0";
            l1.setText(z);
            logger.log("0");
        }

        if(e.getSource()==bDot){  //ADD DECIMAL PTS
            zt=l1.getText();
            z=zt+".";
            l1.setText(z);
            logger.log(".");

        }
        if(e.getSource()==bNegative){ //FOR NEGATIVE
            zt=l1.getText();
            z="-"+zt;
            l1.setText(z);
            logger.log("-");
        }

        if(e.getSource()==bDEL){  // FOR  DEL
            zt=l1.getText();
            try{
                z=zt.substring(0, zt.length()-1);
            }catch(StringIndexOutOfBoundsException f){return;}
            l1.setText(z);
        }
        //AIRTHMETIC BUTTON
        if(e.getSource()==bPlus){
            try{
                num1=Double.parseDouble(l1.getText());
            }catch(NumberFormatException f){
                l1.setText("Invalid Format");
                return;
            }
            z="";
            l1.setText(z);
            check=1;
            logger.log("+");
        }
        if(e.getSource()==bMinus){
            try{
                num1=Double.parseDouble(l1.getText());
            }catch(NumberFormatException f){
                l1.setText("Invalid Format");
                return;
            }
            z="";
            l1.setText(z);
            check=2;
            logger.log("-");
        }
        if(e.getSource()==bMulti){
            try{
                num1=Double.parseDouble(l1.getText());
            }catch(NumberFormatException f){
                l1.setText("Invalid Format");
                return;
            }
            z="";
            l1.setText(z);
            check=3;
            logger.log("*");
        }
        if(e.getSource()==bDivide){
            try{
                num1=Double.parseDouble(l1.getText());
            }catch(NumberFormatException f){
                l1.setText("Invalid Format");
                return;
            }
            z="";
            l1.setText(z);
            check=4;
            logger.log("/");
        }
        if(e.getSource()==bMod){
            try{
                num1=Double.parseDouble(l1.getText());
            }catch(NumberFormatException f){
                l1.setText("Invalid Format");
                return;
            }
            z="";
            l1.setText(z);
            check=5;
            logger.log("%");
        }
        //RESULT BUTTON
        if(e.getSource()==bCalc){
            try{
                num2=Double.parseDouble(l1.getText());
                logger.log("=");
            }catch(Exception f){
                l1.setText("ENTER NUMBER FIRST ");
                return;
            }
            if(check==1){
                xd =num1+num2;
                logger.log(xd);
            }


            if(check==2)
            {
                xd =num1-num2;
                logger.log(xd);
            }
            if(check==3)
            {
                xd =num1*num2;
                logger.log(xd);
            }
            if(check==4)
            {
                xd =num1/num2;
                logger.log(xd);
            }
            if(check==5)
            {
                xd =num1%num2;
                logger.log(xd);
            }
            l1.setText(String.valueOf(xd));
        }
        //FOR CLEARING THE LABEL and Memory
        if(e.getSource()==bAC){
            num1=0;
            num2=0;
            check=0;
            xd=0;
            z="";
            l1.setText(z);
        }

    }
    //MAIN METHOD where objects of MyCalc is instantaiated
    public static void main(String args[]){
        new MyCalc();
    }
}  