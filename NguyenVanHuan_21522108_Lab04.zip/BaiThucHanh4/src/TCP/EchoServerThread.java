package TCP;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import logger.Logger;

public class EchoServerThread {
    static Logger log = new Logger("NguyenVanHuan_21522108_lab04");

    public static final int SERVICE_PORT = 6543;
    // Max size of packet, large enough for almost any client
    public static final int BUFSIZE = 4096;

    public String sentence_from_client;
    public String sentence_to_client;
    private ServerSocket socket;
    public EchoServerThread(){
        log.getClassName("Lab04_TCP_EchoServerThread.java");
        try {
            socket = new ServerSocket(SERVICE_PORT);
            System.out.println("Server active on port " + socket.getLocalPort());
        } catch (IOException e) {
            System.err.print("Unable to bind port");
        }
    }

    public void serviceClients() {
        log.getClassName("Lab04_TCP_EchoServerThread.java");
        while (true) {
            log.getClassName("Lab04_TCP_EchoServerThread.java");
            try {
                Socket connectionSocket = socket.accept();
                System.out.println("New client connected");

                new ServerThread(connectionSocket).start();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

    }
    public static void main(String[] args) {
        log.getClassName("Lab04_TCP_EchoServerThread.java");
        log.info("TCP Multithread Chat: \nDemo");
        EchoServerThread server = new EchoServerThread();
        server.serviceClients();
    }
}
