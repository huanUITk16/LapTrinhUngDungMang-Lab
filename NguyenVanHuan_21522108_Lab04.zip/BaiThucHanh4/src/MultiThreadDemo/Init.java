package MultiThreadDemo;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import logger.Logger;
public class Init {
    static Logger log = new Logger("NguyenVanHuan_21522108_lab04");
    // Khai bao mang kieu int
    int []arr;
    String logString="";
    public Init(){
        log.getClassName("Lab4_MultiThreadDemo_Init.java");
        // Khoi tao mang co 2000 gia tri
        arr = new int[2000];
        // them gia tri cho mang
        for (int i=0;i<arr.length;i++)
        {
            arr[i]=i;
        }
        // Hoan doi vi tri ngau nhien de thanh mang random
        Random rd = ThreadLocalRandom.current();
        for (int i=arr.length-1;i>0;i--){
            int index=rd.nextInt(i+1);
            int tmp = arr[index];
            arr[index] = arr[i];
            arr[i] = tmp;
            logString += arr[i] + " ";
        }

        log.debug("Init: " + logString);
        System.out.println("init complete");
    }
}
