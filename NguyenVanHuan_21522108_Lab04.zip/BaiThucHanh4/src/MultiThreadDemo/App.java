package MultiThreadDemo;

import java.util.Scanner;
import logger.Logger;

public class App {
    static Logger log = new Logger("NguyenVanHuan_21522108_lab04");
    public static void main(String[] args){
        log.getClassName("Lab04_MultiThreadDemo_App.java");
        Init init = new Init();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select 1. Single Thread; 2. Multi Thread");
        int choose = scanner.nextInt();
        switch (choose){
            case 1: {

                System.out.println("input Array:");
                Thread mainThread = new Thread(new MyThread(0, init.arr.length, init.arr, "Main Thread"));
                mainThread.start();

                break;
            }
            case 2: {
                Thread th1 = new Thread(new MyThread(0,19, init.arr, "Thread 1"));
                Thread th2 = new Thread(new MyThread(20,39, init.arr, "Thread 2"));
                Thread th3 = new Thread(new MyThread(40,59, init.arr, "Thread 3"));
                Thread th4 = new Thread(new MyThread(60,79, init.arr, "Thread 4"));
                Thread th5 = new Thread(new MyThread(80,99, init.arr, "Thread 5"));
                th1.start();
                th2.start();
                th3.start();
                th4.start();
                th5.start();
                break;
            }
            default:
                throw new IllegalArgumentException("Unexpected value: " + choose);
        }
    }
}
