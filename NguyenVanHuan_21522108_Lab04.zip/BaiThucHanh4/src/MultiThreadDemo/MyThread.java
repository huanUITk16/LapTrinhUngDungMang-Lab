package MultiThreadDemo;
import logger.Logger;
public class MyThread implements Runnable{
    static Logger log = new Logger("NguyenVanHuan_21522108_lab04");
    int start;
    int end;
    int []arr;
    String name;
    String state = " input";
    long totalTime = 0;
    public MyThread(int start, int end, int [] arr, String name){
        this.start = start;
        this.end = end;
        this.arr = arr;
        this.name = name;
    }


    protected void sort(){
        for (int i=start;i<end;i++){
            for (int j = i+1;j<end;j++)
            {
                if(arr[i] > arr[j]){
                    int tmp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = tmp;
            }

            }
        }
    }
    void bubbleSort() {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (arr[j] > arr[j + 1]) {
                    // swap arr[j+1] và arr[i]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
    }
    protected void print(){
        log.getClassName("Lab04_MultiThreadDemo_MyThread.java");
        String str = this.name + " time: " + totalTime +  state + ":    ";
        for (int i = start; i<end;i++){
            str +=arr[i] + "  ";
        }
        System.out.println(str);
        log.debug(str);
    }
    @Override
    public void run(){
        log.getClassName("Lab04_MultiThreadDemo_MyThread.java");
        print();
        long startTime = System.nanoTime();
        bubbleSort();;
        long endTime = System.nanoTime();
        totalTime = endTime - startTime;
        state = " output";
        print();
    }

}
