import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;
import log.logFile;
public class UDPClient {
    static logFile logger = new logFile("21522108_NguyenVanHuan");
    private static int SERVER_PORT = 5000;
    private static int CLIENT_PORT = 5001;
    private static DatagramSocket socket;
    public static void main(String[] args) throws IOException {
        System.out.println("Connected to server on port " + SERVER_PORT);
        logger.log("Connected to server on port " + SERVER_PORT);
        socket = new DatagramSocket(CLIENT_PORT);
        InetAddress serverAddress = InetAddress.getByName("localhost");
        new Thread(()->{
            while(true) {
                try{
                    byte[] buf = new byte[1024];
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    socket.receive(packet);
                    String received = new String(packet.getData(),0, packet.getLength());
                    System.out.println("Server: " + received);
                    logger.log("Server: " + received);
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();

        Scanner scanner = new Scanner(System.in);
        new Thread(()->{
            while (true){
                String message = scanner.nextLine();
                byte[] buf = message.getBytes();
                DatagramPacket packet = new DatagramPacket(buf, buf.length, serverAddress, SERVER_PORT);
                try{
                    socket.send(packet);
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();
    }
}

