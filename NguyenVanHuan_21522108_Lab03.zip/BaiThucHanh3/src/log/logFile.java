package log;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class logFile {

    private PrintWriter logWriter;

    public logFile(String logFileName) {
        try {
            logWriter = new PrintWriter(new FileWriter(logFileName, true)); // Append mode
        } catch (IOException e) {
            System.err.println("Error creating log file: " + e.getMessage());
        }
    }

    public <T> void log(T message) {
        System.out.println(message); // In ra console
        logWriter.println(message); // Ghi vào tệp log
        logWriter.flush(); // Đảm bảo dữ liệu được ghi ngay lập tức
    }
    public void close() {
        logWriter.close(); // Đóng tệp log
    }

    public static void main(String[] args) {
        logFile logger = new logFile("21522108_NguyenVanHuan.txt");
        logger.log("Hello, orld!");
        logger.log("This is a log message.");
        logger.close();
    }
}