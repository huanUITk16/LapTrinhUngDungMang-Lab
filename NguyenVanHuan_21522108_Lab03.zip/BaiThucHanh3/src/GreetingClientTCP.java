// File Name GreetingClient.java

import java.net.*;
import java.io.*;
import log.logFile;
public class GreetingClientTCP
{
    public static void main(String [] args)
    {
        logFile logger = new logFile("21522108_NguyenVanHuan");
        String tenServer = "localhost";
        int port = 1234;
        try
        {
            System.out.println("Ket noi toi " + tenServer
                    + " on port " + port);
            logger.log("Ket noi toi " + tenServer
                    + " on port " + port);
            Socket client = new Socket(tenServer, port);
            System.out.println("Just connected to "
                    + client.getRemoteSocketAddress());
            logger.log("Just connected to "
                    + client.getRemoteSocketAddress());
            OutputStream outToServer = client.getOutputStream();
            DataOutputStream out =
                    new DataOutputStream(outToServer);

            out.writeUTF("Hello from "
                    + client.getLocalSocketAddress());
            logger.log("Hello from " + client.getLocalSocketAddress());
            InputStream inFromServer = client.getInputStream();
            DataInputStream in =
                    new DataInputStream(inFromServer);
            System.out.println("Server says " + in.readUTF());
            logger.log("Server says " + in.readUTF());

            client.close();
        }catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
