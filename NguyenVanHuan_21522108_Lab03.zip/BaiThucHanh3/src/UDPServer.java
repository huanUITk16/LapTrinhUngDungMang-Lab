import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;
import log.logFile;

public class UDPServer {
    private static DatagramSocket socket;
    private static int PORT = 5000;
    public static InetAddress address;
    public static int port;
    static logFile logger = new logFile("21522108_NguyenVanHuan");
    public static void main (String[]args) throws IOException{
        socket = new DatagramSocket(PORT);
        System.out.println(("Server started on port "+ PORT));
        logger.log("Server started on port "+ PORT);
        Scanner scanner = new Scanner(System.in);
        new Thread(()->{
            while (true){
                try{
                    byte[] buf = new byte[1024];
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    socket.receive(packet);
                    address = packet.getAddress();
                    port = packet.getPort();
                    String received = new String(packet.getData(),0,packet.getLength());
                    System.out.println("Client: " + received);
                    logger.log("Client: " + received);
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();

        new Thread(()->{
            while(true){
                String message = scanner.nextLine();
                byte[] buf = message.getBytes();
                DatagramPacket packet = new DatagramPacket(buf, buf.length, address, port);
                try{
                    socket.send(packet);
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();




    }




}
