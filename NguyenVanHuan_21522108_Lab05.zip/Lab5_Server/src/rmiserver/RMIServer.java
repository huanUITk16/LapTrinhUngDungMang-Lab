package rmiserver;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import logger.Logger;
public class RMIServer {
    static Logger log = new Logger("NguyenVanHuan_21522108_lab05");
    public static void main(String[] args) {
        // TODO code application logic here
        try {

            LocateRegistry.createRegistry(5000);
            Naming.bind("rmi://localhost:5000/MyServices", new MathObject());
            System.out.println("Server Started!!!");

        }
        catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
