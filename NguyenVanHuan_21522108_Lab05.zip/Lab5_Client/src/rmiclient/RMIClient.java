package rmiclient;

import logger.Logger;
import rmiserver.IMath;

import java.rmi.Naming;

public class RMIClient {
    static Logger log = new Logger("NguyenVanHuan_21522108_lab05");
    public static void main(String[] args) {

        // TODO code application logic here
        try {
            IMath imath = (IMath) Naming.lookup("rmi://localhost:5000/MyServices");
            int add = imath.add(2,4);
            int sub = imath.sub(10,2);
            int multi = imath.mul(5,3);
            int div = imath.div(100,5);
            System.out.println("Result: " + add + " " + sub + " " + multi + " " + div);
            log.debug("Result: " + add + " " + sub + " " + multi + " " + div);
        }
        catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
